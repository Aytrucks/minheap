#ifndef _util_h
#define _util_h 1

int  nextInstruction(char* Word,int* position, double* key, double* capacity);

#endif